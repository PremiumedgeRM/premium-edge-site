import Image from "next/image"
import Link from "next/link"
import { Phone, Mail, MapPin, Clock, CheckCircle, Facebook } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_0654.PNG-x4iDHuSzP4LGlRvzutfDs4oD4oKcO8.jpeg"
              alt="Premium Edge Curbing LLC Logo"
              width={240}
              height={80}
              className="h-14 w-auto"
            />
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="#services" className="text-sm font-medium hover:text-primary transition-colors">
              Services
            </Link>
            <Link href="#benefits" className="text-sm font-medium hover:text-primary transition-colors">
              Benefits
            </Link>
            <Link href="#gallery" className="text-sm font-medium hover:text-primary transition-colors">
              Gallery
            </Link>
            <Link href="#contact" className="text-sm font-medium hover:text-primary transition-colors">
              Contact
            </Link>
            <a
              href="https://www.facebook.com/profile.php?id=100092278278851"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm font-medium hover:text-primary transition-colors"
              aria-label="Visit our Facebook page"
            >
              <Facebook className="h-5 w-5" />
            </a>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="#contact" className="hidden md:flex">
              <Button>Get a Free Quote</Button>
            </Link>
            <a href="tel:5179606046" className="flex items-center gap-2 text-sm font-medium md:hidden">
              <Phone className="h-4 w-4" />
              <span className="sr-only">Call us</span>
            </a>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="relative">
          <div className="absolute inset-0 bg-black/60 z-10" />
          <div className="container relative z-20 py-24 md:py-32 lg:py-40">
            <div className="flex flex-col items-start gap-4 max-w-xl">
              <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl md:text-6xl">
                Transform Your Landscape With Premium Concrete Curbing
              </h1>
              <p className="text-xl text-white/90">
                Professional concrete landscape curbing for residential and commercial properties in Jackson, Michigan
                and surrounding areas.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mt-4">
                <Link href="#contact">
                  <Button size="lg" className="bg-[#5aff5a] hover:bg-[#4ae64a] text-black font-bold">
                    Get a Free Quote
                  </Button>
                </Link>
                <Link href="#gallery">
                  <Button size="lg" className="bg-[#5aff5a] hover:bg-[#4ae64a] text-black font-bold">
                    View Our Work
                  </Button>
                </Link>
              </div>
            </div>
          </div>
          <div className="absolute inset-0 z-0">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/20230822_115726.jpg-ieh86T2JYhdIrZd1ajYhQgSHnv6kT8.jpeg"
              alt="Concrete curbing example"
              fill
              className="object-cover"
              priority
            />
          </div>
        </section>

        <section id="services" className="py-16 md:py-24 bg-white">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Our Curbing Services</h2>
              <p className="mt-4 text-xl text-muted-foreground max-w-3xl mx-auto">
                We provide high-quality concrete landscape curbing solutions for both residential and commercial
                properties.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card shadow-sm">
                <div className="h-14 w-14 rounded-full bg-[#5aff5a]/20 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-[#5aff5a]"
                  >
                    <path d="M12 22c-4.97 0-9-2.24-9-5v-3.33c0-.7.19-1.37.53-1.99" />
                    <path d="M12 22c4.97 0 9-2.24 9-5v-3.33c0-.7-.19-1.37-.53-1.99" />
                    <path d="M12 22V12" />
                    <path d="M5 4.31C5.64 3.77 6.57 3.35 7.6 3.09" />
                    <path d="M19 4.31c-.64-.54-1.57-.96-2.6-1.22" />
                    <path d="M12 7c4.97 0 9-1.12 9-2.5S16.97 2 12 2 3 3.12 3 4.5 7.03 7 12 7Z" />
                    <path d="M12 12c4.97 0 9-1.12 9-2.5V7" />
                    <path d="M3 7v2.5C3 10.88 7.03 12 12 12" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">Residential Curbing</h3>
                <p className="text-muted-foreground">
                  Enhance your home's landscape with decorative concrete curbing that adds beauty and value to your
                  property.
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card shadow-sm">
                <div className="h-14 w-14 rounded-full bg-[#5aff5a]/20 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-[#5aff5a]"
                  >
                    <rect width="16" height="20" x="4" y="2" rx="2" />
                    <path d="M9 22v-4h6v4" />
                    <path d="M8 6h.01" />
                    <path d="M16 6h.01" />
                    <path d="M12 6h.01" />
                    <path d="M8 10h.01" />
                    <path d="M16 10h.01" />
                    <path d="M12 10h.01" />
                    <path d="M8 14h.01" />
                    <path d="M16 14h.01" />
                    <path d="M12 14h.01" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">Commercial Curbing</h3>
                <p className="text-muted-foreground">
                  Professional curbing solutions for businesses, office parks, and commercial properties that enhance
                  curb appeal.
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-6 rounded-lg border bg-card shadow-sm">
                <div className="h-14 w-14 rounded-full bg-[#5aff5a]/20 flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-[#5aff5a]"
                  >
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                    <path d="m9 12 2 2 4-4" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-2">Custom Designs</h3>
                <p className="text-muted-foreground">
                  Choose from various colors, patterns, and textures to create a unique look that complements your
                  property.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="benefits" className="py-16 md:py-24 bg-gray-50">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
                Benefits of Concrete Curbing
              </h2>
              <p className="mt-4 text-xl text-muted-foreground max-w-3xl mx-auto">
                Discover why our concrete landscape curbing is the preferred choice for property owners.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
              <div className="flex flex-col gap-6">
                <div className="flex gap-4">
                  <CheckCircle className="h-6 w-6 text-[#5aff5a] flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-bold">Durable & Long-Lasting</h3>
                    <p className="text-muted-foreground">
                      Our concrete curbing is built to last for years, withstanding harsh weather conditions and
                      seasonal changes.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <CheckCircle className="h-6 w-6 text-[#5aff5a] flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-bold">Low Maintenance</h3>
                    <p className="text-muted-foreground">
                      Unlike traditional edging, our concrete curbing requires minimal upkeep and stays in place year
                      after year.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <CheckCircle className="h-6 w-6 text-[#5aff5a] flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-bold">Weed Control</h3>
                    <p className="text-muted-foreground">
                      Creates a barrier that helps prevent grass and weeds from invading your garden beds and landscaped
                      areas.
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex flex-col gap-6">
                <div className="flex gap-4">
                  <CheckCircle className="h-6 w-6 text-[#5aff5a] flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-bold">Enhances Property Value</h3>
                    <p className="text-muted-foreground">
                      Adds a professional, finished look to your landscape that can increase your property's curb appeal
                      and value.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <CheckCircle className="h-6 w-6 text-[#5aff5a] flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-bold">Customizable Options</h3>
                    <p className="text-muted-foreground">
                      Available in various colors, patterns, and styles to match your existing landscape and
                      architectural design.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <CheckCircle className="h-6 w-6 text-[#5aff5a] flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-bold">Mowing Edge</h3>
                    <p className="text-muted-foreground">
                      Creates a clean mowing edge that eliminates the need for string trimming and makes lawn
                      maintenance easier.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="gallery" className="py-16 md:py-24 bg-white">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Our Work</h2>
              <p className="mt-4 text-xl text-muted-foreground max-w-3xl mx-auto">
                Browse through some of our recent concrete curbing projects in Jackson, Michigan.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="relative aspect-square overflow-hidden rounded-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/20230822_115726.jpg-ieh86T2JYhdIrZd1ajYhQgSHnv6kT8.jpeg"
                  alt="Residential concrete curbing around a rock garden"
                  fill
                  className="object-cover transition-transform hover:scale-105"
                />
                <div className="bg-card p-4">
                  <h3 className="font-medium">Residential Landscape Curbing</h3>
                  <p className="text-sm text-muted-foreground">Clean separation between lawn and rock garden</p>
                </div>
              </div>
              <div className="relative aspect-square overflow-hidden rounded-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/20231007_135527.jpg-wqQq8Qjstv9Kbh3oaMjtKjqiPLKL1o.jpeg"
                  alt="Backyard patio area with concrete curbing"
                  fill
                  className="object-cover transition-transform hover:scale-105"
                />
                <div className="bg-card p-4">
                  <h3 className="font-medium">Patio Area Border</h3>
                  <p className="text-sm text-muted-foreground">Defining outdoor living spaces with elegant curbing</p>
                </div>
              </div>
              <div className="relative aspect-square overflow-hidden rounded-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/FB_IMG_1707415179539.jpg-DoYlgd8UOlnpofnFTxiS3ZMtYnkX1x.jpeg"
                  alt="House foundation concrete curbing"
                  fill
                  className="object-cover transition-transform hover:scale-105"
                />
                <div className="bg-card p-4">
                  <h3 className="font-medium">Foundation Landscaping</h3>
                  <p className="text-sm text-muted-foreground">Curved curbing with rock bed installation</p>
                </div>
              </div>
              <div className="relative aspect-square overflow-hidden rounded-lg">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/received_1314415712499606-u7JktVkKJeCCy98Dx3ndhHoSekJ2od.jpeg"
                  alt="Decorative curved concrete curbing"
                  fill
                  className="object-cover transition-transform hover:scale-105"
                />
                <div className="bg-card p-4">
                  <h3 className="font-medium">Decorative Curbing</h3>
                  <p className="text-sm text-muted-foreground">Stamped finish with elegant curves</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-24 bg-gray-900 text-white">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl text-white">Customer Reviews</h2>
              <p className="mt-4 text-xl text-gray-300 max-w-3xl mx-auto">
                Don't just take our word for it. Here's what our customers have to say about our work.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700">
                <div className="flex items-center mb-4">
                  <div className="flex text-[#5aff5a]">
                    {[...Array(5)].map((_, i) => (
                      <svg
                        key={i}
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        className="mr-1"
                      >
                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                      </svg>
                    ))}
                  </div>
                </div>
                <p className="text-gray-300 mb-4">
                  "Premium Edge Curbing transformed our front yard! The curbing looks fantastic and has held up
                  perfectly through Michigan's harsh winter. Highly recommend their services."
                </p>
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-gray-700 flex items-center justify-center mr-3">
                    <span className="text-[#5aff5a] font-bold">JD</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-white">John Donovan</h4>
                    <p className="text-sm text-gray-400">Jackson, MI</p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700">
                <div className="flex items-center mb-4">
                  <div className="flex text-[#5aff5a]">
                    {[...Array(5)].map((_, i) => (
                      <svg
                        key={i}
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        className="mr-1"
                      >
                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                      </svg>
                    ))}
                  </div>
                </div>
                <p className="text-gray-300 mb-4">
                  "Mike and Rob were professional from start to finish. They helped me design the perfect curbing for my
                  garden beds and executed flawlessly. The curbing has made lawn maintenance so much easier!"
                </p>
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-gray-700 flex items-center justify-center mr-3">
                    <span className="text-[#5aff5a] font-bold">SM</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-white">Sarah Mitchell</h4>
                    <p className="text-sm text-gray-400">Ann Arbor, MI</p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700">
                <div className="flex items-center mb-4">
                  <div className="flex text-[#5aff5a]">
                    {[...Array(4)].map((_, i) => (
                      <svg
                        key={i}
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        className="mr-1"
                      >
                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                      </svg>
                    ))}
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="mr-1"
                    >
                      <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                    </svg>
                  </div>
                </div>
                <p className="text-gray-300 mb-4">
                  "We had Premium Edge install curbing around our commercial property. The work was completed on time
                  and on budget. The curbing has dramatically improved the appearance of our landscaping."
                </p>
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-gray-700 flex items-center justify-center mr-3">
                    <span className="text-[#5aff5a] font-bold">RJ</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-white">Robert Johnson</h4>
                    <p className="text-sm text-gray-400">Business Owner</p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700 lg:col-span-2">
                <div className="flex items-center mb-4">
                  <div className="flex text-[#5aff5a]">
                    {[...Array(5)].map((_, i) => (
                      <svg
                        key={i}
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        className="mr-1"
                      >
                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                      </svg>
                    ))}
                  </div>
                </div>
                <p className="text-gray-300 mb-4">
                  "I can't say enough good things about Premium Edge Curbing. They completely transformed our backyard
                  with their beautiful concrete curbing. The team was punctual, professional, and paid attention to
                  every detail. The stamped pattern we chose looks amazing and has held up perfectly for over a year
                  now. Our neighbors have all asked for their contact information!"
                </p>
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-gray-700 flex items-center justify-center mr-3">
                    <span className="text-[#5aff5a] font-bold">LW</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-white">Lisa Williams</h4>
                    <p className="text-sm text-gray-400">Lansing, MI</p>
                  </div>
                </div>
              </div>

              <div className="bg-gray-800 p-6 rounded-lg shadow-lg border border-gray-700">
                <div className="flex items-center mb-4">
                  <div className="flex text-[#5aff5a]">
                    {[...Array(5)].map((_, i) => (
                      <svg
                        key={i}
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                        className="mr-1"
                      >
                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                      </svg>
                    ))}
                  </div>
                </div>
                <p className="text-gray-300 mb-4">
                  "After getting quotes from several companies, we chose Premium Edge for our landscape curbing project.
                  Best decision ever! Their pricing was competitive and the quality of work was outstanding. The curbing
                  has completely eliminated our edging maintenance."
                </p>
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-gray-700 flex items-center justify-center mr-3">
                    <span className="text-[#5aff5a] font-bold">DP</span>
                  </div>
                  <div>
                    <h4 className="font-medium text-white">David Parker</h4>
                    <p className="text-sm text-gray-400">Chelsea, MI</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-12 text-center">
              <Link href="#contact">
                <Button size="lg" className="bg-[#5aff5a] hover:bg-[#4ae64a] text-black font-bold">
                  Get Your Free Quote Today
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-24 bg-black text-white">
          <div className="container">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl text-white mb-6">
                  Why Choose Premium Edge Curbing?
                </h2>
                <div className="space-y-4">
                  <div className="flex gap-4 items-start">
                    <div className="h-10 w-10 rounded-full bg-[#5aff5a] flex items-center justify-center flex-shrink-0">
                      <span className="font-bold text-black">1</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white">Experienced Professionals</h3>
                      <p className="text-white/80">
                        Our team has years of experience in concrete curbing installation for both residential and
                        commercial properties.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4 items-start">
                    <div className="h-10 w-10 rounded-full bg-[#5aff5a] flex items-center justify-center flex-shrink-0">
                      <span className="font-bold text-black">2</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white">Quality Materials</h3>
                      <p className="text-white/80">
                        We use only high-quality concrete mixes and reinforcement materials to ensure durability and
                        longevity.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4 items-start">
                    <div className="h-10 w-10 rounded-full bg-[#5aff5a] flex items-center justify-center flex-shrink-0">
                      <span className="font-bold text-black">3</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white">Customer Satisfaction</h3>
                      <p className="text-white/80">
                        We pride ourselves on delivering exceptional service and results that exceed our customers'
                        expectations.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="relative h-[400px] rounded-lg overflow-hidden">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_0654.PNG-x4iDHuSzP4LGlRvzutfDs4oD4oKcO8.jpeg"
                  alt="Premium Edge Curbing LLC Logo"
                  fill
                  className="object-contain bg-black"
                />
              </div>
            </div>
          </div>
        </section>

        <section id="contact" className="py-16 md:py-24 bg-gray-50">
          <div className="container">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <div>
                <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Contact Us</h2>
                <p className="mt-4 text-xl text-muted-foreground">
                  Ready to transform your landscape? Get in touch with us for a free quote or to learn Ready to
                  transform your landscape? Get in touch with us for a free quote or to learn more about our services.
                </p>
                <div className="mt-8 space-y-6">
                  <div className="flex items-start gap-4">
                    {" "}
                    <Phone className="h-6 w-6 text-[#5aff5a] flex-shrink-0" />
                    <div>
                      <h3 className="font-medium">Phone</h3>
                      <div className="space-y-2">
                        <p>
                          Mike Pool:{" "}
                          <a href="tel:5172066295" className="hover:text-[#5aff5a]">
                            517-206-6295
                          </a>
                        </p>
                        <p>
                          Rob Fraser:{" "}
                          <a href="tel:5179606046" className="hover:text-[#5aff5a]">
                            517-960-6046
                          </a>
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Mail className="h-6 w-6 text-[#5aff5a] flex-shrink-0" />
                    <div>
                      <h3 className="font-medium">Email</h3>
                      <p className="mt-1">
                        <a href="mailto:premiumedgecurbing@gmail.com" className="hover:text-[#5aff5a]">
                          premiumedgecurbing@gmail.com
                        </a>
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <MapPin className="h-6 w-6 text-[#5aff5a] flex-shrink-0" />
                    <div>
                      <h3 className="font-medium">Location</h3>
                      <p className="mt-1">Serving Jackson, Michigan and surrounding areas</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <Clock className="h-6 w-6 text-[#5aff5a] flex-shrink-0" />
                    <div>
                      <h3 className="font-medium">Business Hours</h3>
                      <p className="mt-1">
                        Monday - Friday: 6:00 AM - 7:00 PM
                        <br />
                        Saturday: 8:00 AM - 7:00 PM
                        <br />
                        Sunday: Closed
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-sm border">
                <h3 className="text-xl font-bold mb-4">Request a Free Quote</h3>
                <form className="space-y-4">
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div className="space-y-2">
                      <label
                        htmlFor="first-name"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        First Name
                      </label>
                      <input
                        id="first-name"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        placeholder="John"
                      />
                    </div>
                    <div className="space-y-2">
                      <label
                        htmlFor="last-name"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Last Name
                      </label>
                      <input
                        id="last-name"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        placeholder="Doe"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label
                      htmlFor="email"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Email
                    </label>
                    <input
                      id="email"
                      type="email"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="john.doe@example.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <label
                      htmlFor="phone"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Phone
                    </label>
                    <input
                      id="phone"
                      type="tel"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="(123) 456-7890"
                    />
                  </div>
                  <div className="space-y-2">
                    <label
                      htmlFor="project-type"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Project Type
                    </label>
                    <select
                      id="project-type"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      <option value="">Select project type</option>
                      <option value="residential">Residential</option>
                      <option value="commercial">Commercial</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label
                      htmlFor="message"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Message
                    </label>
                    <textarea
                      id="message"
                      className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      placeholder="Tell us about your project..."
                    />
                  </div>
                  <Button type="submit" className="w-full bg-[#5aff5a] hover:bg-[#4ae64a] text-black font-bold">
                    Submit Request
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </section>

        <section className="py-12 bg-[#5aff5a]">
          <div className="container">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div>
                <h2 className="text-2xl md:text-3xl font-bold text-black">Ready to enhance your landscape?</h2>
                <p className="text-black/80 mt-2 text-lg">Contact us today for a free consultation and quote.</p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <a href="tel:5179606046">
                  <Button size="lg" className="bg-black hover:bg-black/80 text-white">
                    Call Now: 517-206-6295
                  </Button>
                </a>
                <Link href="#contact">
                  <Button size="lg" variant="outline" className="border-black text-black hover:bg-black/10">
                    Request a Quote
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="bg-black text-white py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/IMG_0654.PNG-x4iDHuSzP4LGlRvzutfDs4oD4oKcO8.jpeg"
                alt="Premium Edge Curbing LLC Logo"
                width={200}
                height={80}
                className="mb-4"
              />
              <p className="text-white/70 mt-4">
                Professional concrete landscape curbing services in Jackson, Michigan and surrounding areas.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Contact Information</h3>
              <div className="space-y-2">
                <p className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-[#5aff5a]" />
                  <span>Mike Pool: 517-206-6295</span>
                </p>
                <p className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-[#5aff5a]" />
                  <span>Rob Fraser: 517-960-6046</span>
                </p>
                <p className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-[#5aff5a]" />
                  <span>premiumedgecurbing@gmail.com</span>
                </p>
                <p className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-[#5aff5a]" />
                  <span>Jackson, Michigan</span>
                </p>
              </div>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4">Quick Links</h3>
              <nav className="flex flex-col space-y-2 ml-5">
                <Link href="#services" className="text-white/70 hover:text-white">
                  Services
                </Link>
                <Link href="#benefits" className="text-white/70 hover:text-white">
                  Benefits
                </Link>
                <Link href="#gallery" className="text-white/70 hover:text-white">
                  Gallery
                </Link>
                <Link href="#contact" className="text-white/70 hover:text-white">
                  Contact
                </Link>
              </nav>
            </div>
          </div>
          <div className="border-t border-white/20 mt-8 pt-8 text-center text-white/60">
            <p>&copy; {new Date().getFullYear()} Premium Edge Curbing LLC. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

